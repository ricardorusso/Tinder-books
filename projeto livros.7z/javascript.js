


var x= 5;
var y=-1;
var z= 20;

if (x < y ){console.log(y)}
else (console.log(x))

if (x >= 0) { "the sign is +"}

else {"the sign is -"}


/*Write a JavaScript program to sort three numbers.

Example:
    Sample numbers : 0, -1, 4 
    Output : 4, 0, -1 */

if (x>y && x>z)
{
        if (y>z)
        {
            console.log(x + ", " + y + ", " +z);
        }
        else
        {
            console.log(x + ", " + z + ", " +y);
        }
}
else if (y>x && y >z)
{
        if (x>z)
        {
             console.log(y + ", " + x + ", " +z);
        }
        else
        {
             console.log(y + ", " + z + ", " +x);
        }
}
else if (z>x && z>y)
{
        if (x>y)
        {
            console.log(z + ", " + x + ", " +y);
        }
        else
        {
            console.log(z + ", " + y + ", " +x);
        }
}        

/*Enviar para a consola o maior de 5 números

Example:
    Sample numbers : -5, -2, -6, 0, -1 
    Output : 0 
Através de um loop, contar até 15 e enviar para a consola se o número é par ou impar

Example:
    "0 is even" 
    "1 is odd" 
    "2 is even" 
    (.........)
Enviar para a consola a soma dos múltiplos de 3 e 5 até ao número 1000 */

var a = 1

var b = 2

var c = 3

var d = 4

var e = 6

if (a>b && a>c && a>d && a > e){console.log(a)}
else if (b>a && b>c && b>d && b > e){console.log(b)}
else if (c>a && c>b && c>d && c > e){console.log(c)}
else if (d>a && d>b && d>c && d > e){console.log(d)}
else {console.log(e)}





for(i=0;i<=15;i++)
{
    if(i%2==0){
		console.log(i +" is even");
    }
    else{
        console.log(i +" is odd");
    }
}

/*Enviar para a consola a soma dos múltiplos de 3 e 5 até ao número 1000 */
var x = 0
for(i=1;i<1000;i++)
{
       if(i%3==0)
       {
           x=x+i;
        }
       else if(i%5==0)
       {x=x+i;}

}
 /*Calcular a média das notas e enviar a nota correspondente à media para a consola*/

var a = 12
var b = 14
var c = 56
var d = 5
var e = 90

x=(a+b+c+d+e)/5

if (x<60)
    {
        console.log(" F")
    }
else if (x<70)
{
    console.log(" D")
}
else if (x<80)
{
    console.log(" C")
}
else if (x<90)
{
    console.log(" B")
}
else if (x<=100)
{
    console.log(" A")
}